package LastApt;

public class AddrVO {
	private int addr_carnum;
	private int addr_num;
	
	public int getAddr_carnum() {
		return addr_carnum;
	}
	public void setAddr_carnum(int addr_carnum) {
		this.addr_carnum = addr_carnum;
	}
	public int getAddr_num() {
		return addr_num;
	}
	public void setAddr_num(int addr_num) {
		this.addr_num = addr_num;
	}

	

}
